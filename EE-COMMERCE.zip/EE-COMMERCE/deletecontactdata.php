<?php
include("connection.php");
$Name= $_GET['name'];
$query = "DELETE FROM contact where name ='$Name'";
$data = mysqli_query($conn, $query);
if($data)
{
    echo "<script>alert('Record Deleted')</script>";
   
    ?>
          
    <meta http-equiv="refresh" content="0; url=http://localhost/Project/E-COMMERCE/contactdata.php" />

    <?php
}
else{
    echo "<script>alert('Failed To Delete')</script>";
}
?>



