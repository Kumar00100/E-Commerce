<?php
include("connection.php");
$Username= $_GET['Username'];
$query = "DELETE FROM register where Username ='$Username'";
$data = mysqli_query($conn, $query);
if($data)
{
    echo "<script>alert('Record Deleted')</script>";
   
    ?>
          
    <meta http-equiv="refresh" content="0; url=http://localhost/PROJECT/E-COMMERCE/accountregisterdata.php" />

    <?php
}
else{
    echo "<script>alert('Failed To Delete')</script>";
}
?>



