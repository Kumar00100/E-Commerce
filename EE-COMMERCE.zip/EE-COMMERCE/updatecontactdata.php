<?php 
include("connection.php");

if (isset($_GET['name'])) {
    $Name= $_GET['name'];
    $query = "SELECT * FROM contact where name ='$Name'";
    $data = mysqli_query($conn, $query);
    $result=mysqli_fetch_assoc($data);
    $Name = $result['Name'];
    $Mail = $result['Mail'];
    $Subject = $result['Subject'];
    $Message = $result['Message'];
} 
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viwport" content="width=device-width.initial-scale=1">
        <link rel="stylesheet" href="style.css">
        <title>UPDATE CONTACT DATA</title>
    </head>

    <body>
        <div class="title">UPDATE CONTACT DATA</div>

        <section id="form-details">
            <form action="#" method="POST">
                <span>LEAVE A MESSAGE</span>
                <h2>We Love To Hear From You</h2>
                <input type="text" name="Name" placeholder="Your Name" value="<?php echo isset($Name) ? $Name : '' ?>">
                <input type="text" name="Mail" placeholder="E-Mail" value="<?php echo isset($Mail) ? $Mail : '' ?>">
                <input type="text" name="Subject" placeholder="Subject" value="<?php echo isset($Subject) ? $Subject : '' ?>">
                <textarea name="Message" cols="30" rows="10" placeholder="Your Message"><?php echo isset($Message) ? $Message : '' ?></textarea>
                <button class="btn" name="submit">Update Details</button>
            </form>
        </section>
    
    </body>
</html> 

<?php
if(isset($_POST['submit'])) {
    $Name = isset($_POST['Name']) ? $_POST['Name'] : '';
    $Mail = isset($_POST['Mail']) ? $_POST['Mail'] : '';
    $Subject = isset($_POST['Subject']) ? $_POST['Subject'] : '';
    $Message = isset($_POST['Message']) ? $_POST['Message'] : '';

    if($Name !== '' && $Mail !== '' && $Subject !== '' && $Message !== '') {
        $query ="UPDATE contact SET name='$Name', Mail='$Mail',Subject='$Subject',Message='$Message' WHERE name='$Name'";
        $data = mysqli_query($conn,$query);
        
        if($data) {
            echo "<script>alert('Record Updated')</script>";
            ?>
            <meta http-equiv="refresh" content="0; url=http://localhost/Project/E-COMMERCE/contactdata.php" />
            <?php
        } else {
            echo "Failed to Update";
        }
    } else {
        echo "<script>alert('Fill The Form First');</script>";
    }
}
?>
