<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>All Products - TRY BASKET</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<body>

    <div class="container">
        <div class="navbar">
            <div class="logo">
               <img src="logo.png" width="125px">
            </div>
            <nav>
                <ul>
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="products.php">PRODUCTS</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                    <li><a href="account.php">ACCOUNT</a></li>
                </ul>
            </nav>
            <a href="cart.php"> <img src="images/cart.png" width="30px" height="30px"></a>
        </div>
    </div>






    <div class="small-container single-product">
        <div class="row">
            <div class="col-2">
                <img src="images/f1.png" width="100%" id="ProductImg">
                <div class="small-img-row">
                    <div class="small-img-col">
                        <img src="images/f2.png" width="100%" class="small-img">
                    </div>
                    <div class="small-img-col">
                        <img src="images/f3.png" width="100%" class="small-img">
                    </div>
                    <div class="small-img-col">
                        <img src="images/f4.png" width="100%" class="small-img">
                    </div>
                    <div class="small-img-col">
                        <img src="images/f5.png" width="100%" class="small-img">
                    </div>
                </div> 
            </div>

            <form action="manage_cart.php" method="POST">




            <div class="col-2">
                <p>Home / Watch</p>
                <h1>Fossil Black Watch</h1>
                <h4>12145.00/-</h4>
           
                
                <input type="number"  min="1" value="1" required>

                <button type="submit" name="Add_To_Cart" class="btn">Add To Cart</button>
                <input type="hidden" name="product_name" value="Fossil Black Watch">
                <input type="hidden" name="price" value="12145.00">
                <h3>Product Details <i class="fa fa-indent"></i></h3><br>
                <table>
  <tr>
    <td>Water Resistant:</td>
    <td>Yes</td>
  </tr>
  <tr>
    <td>Display Type:</td>
    <td>Analog</td>
  </tr>
  <tr>
    <td>Style Code:</td>
    <td>FS5848</td>
  </tr>
  <tr>
    <td>Series:</td>
    <td>Minimalist</td>
  </tr>
  <tr>
    <td>Occasion:</td>
    <td>Casual</td>
  </tr>
  <tr>
    <td>Watch Type:</td>
    <td>Wrist Watch</td>
  </tr>
  <tr>
    <td>Pack of:</td>
    <td>1</td>
  </tr>
</table>

            </div>
            </form>
        </div>
    </div>







<div class="small-container">
    <div class="row row-2">
        <h2> Realated Products </h2>
       
           
       
    </div>
</div>

  <div class="small-container">
            <div class="row">
                <div class="col-4">
                    <a href="roadsterwatch.php">
                    <img src="images/r1.png"></a>
                    <h4>Roadster Analog Watch</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>1149.00</p>
                </div>
                <div class="col-4">
                    <a href="campusshoe.php">
                    <img src="images/c1.png"></a>
                    <h4>Campus Sneaker</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half-o"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>1749.00</p>
                </div>
                <div class="col-4">
                    <a href="running.php">
                    <img src="images/ru1.png"></a>
                    <h4>Running Shoe</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half-o"></i>
                    </div>
                    <p>699.00</p>
                </div>
                <div class="col-4">
                    <a href="Nike Jogger.php">
                    <img src="images/product-12.jpg"></a>
                    <h4>Nike Jogger</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>1199.00</p>
                </div>
            </div>
        </div>
  
    </div>

    <div class="footer">
    <div class="container">
        <div class="row">
            <div class="footer-col-1">
                <h3>DOWNLOAD OUR APP</h3>
                <p>Download App for Android and iOS mobile phones.</p>
                <div class="app-logo">
                    <img src="images/play-store.png">
                    <img src="images/app-store.png">
                </div>
            </div>
            <div class="footer-col-2">
                <img src="logo1.jpg">
                <p>Shop With Us and You'll Love The Way You Look</p>
            </div>
            <div class="footer-col-3">
                <h3>USEFUL LINKS</h3>
                <ul>
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="products.php">PRODUCTS</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                    <li><a href="account.php">ACCOUNT</a></li>
                </ul>
            </div>
            <div class="footer-col-4">
                <h3>Follow Us</h3>
                <ul>
                    <li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook-official"></i> Facebook</a></li>
                    <li><a href="https://www.instagram.com/" target="_blank"><i class="fa fa-instagram"></i> Instagram</a></li>
                    <li><a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter"></i> Twitter</a></li>
                </ul>
            </div>
        </div>
        <hr>
        <p class="Copyright"> TRY BASKET</p>
    </div>
</div>

      <script>
        var ProductImg=document.getElementById("ProductImg");
        var SmallImg=document.getElementsByClassName("small-img");
        SmallImg[0].onclick=function()
        {
       ProductImg.src=SmallImg[0].src;
        }
        SmallImg[1].onclick=function()
        {
       ProductImg.src=SmallImg[1].src;
        }
        SmallImg[2].onclick=function()
        {
       ProductImg.src=SmallImg[2].src;
        }
        SmallImg[3].onclick=function()
        {
       ProductImg.src=SmallImg[3].src;
        }
    </script>
  </body>
  </html>
      