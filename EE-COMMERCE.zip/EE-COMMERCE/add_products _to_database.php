<?php include("connection.php");?>



<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viwport" content="width=device-width.initial-scale=1">
        <link rel="stylesheet" href="style.css">
        <title>ADD PRODUCTS TO DATABASE</title>
</head>


<body>
    <div class="container">
        <form action="#"  method="POST">
        <div class="title">ADD PRODUCTS TO DATABASE</div>


        <div class="form">

            <div class="input_field">
                <label>product_name</label>
                <input type="text" class="input" name="product_name" required>
            </div> 

            <div class="input_field">
                <label>qty</label>
                <input type="text" class="input" name="qty" required>
            </div>

            <div class="input_field">
                <label>price</label>
                <input type="text" class="input" name="price" required>
            </div>

            <div class="input_field">
                <input type="submit" value="Insert" class="btn" name="insert">
            </div>



        </div>

</form>
    </div>
    </body>
    </html> 




    <?php

if(isset($_POST['insert']))
        {
          $product_name = $_POST['product_name'];
          $qty = $_POST['qty'];
          $price = $_POST['price'];
    


          if($product_name !="" && $qty !="" && $price !="" )

        {
          $query ="INSERT INTO products (product_name,qty,price)values('$product_name','$qty','$price')";
          $data = mysqli_query($conn,$query);
          if($data)
          {
            echo "Data Inserted Into Database";
          }
          else{
            echo "Failed";
          }
        }
else{
    echo "<script>alert('Fill The Form First');</script>";
}
    }

    ?>