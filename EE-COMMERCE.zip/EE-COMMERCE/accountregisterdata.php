<html>
<head>
    <title>ACCOUNT REGISTER DATA</title>
    <style>
        body {
            background:#D071f9;
        }
        table {
            background-color:white;
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        .update {
            background-color:green;
            color:white;
            border:0;
            outline:none;
            border-radius:5px;
            height:30px;
            width:80px;
            font-weight:bold;
            cursor:pointer;
        }
        .delete {
            background-color:red;
            color:white;
            border:0;
            outline:none;
            border-radius:5px;
            height:30px;
            width:80px;
            font-weight:bold;
            cursor:pointer;
        }
    </style>
</head>

<body>
<?php
include("connection.php");

if(isset($_POST['Submit'])) {
    $Username = $_POST['Username'];
    $Email = $_POST['Email'];
    $Password = $_POST['Password'];

    $query = "INSERT INTO register (Username, Email, Password) VALUES ('$Username', '$Email', '$Password')";

    $data = mysqli_query($conn, $query);

    if($data) {
        echo "Registration Successful!";
    } else {
        echo "Failed to Register: " . mysqli_error($conn);
    }
}
?>

<script>
    function checkdelete() {
        return confirm('Are you sure you want to delete this Record?');
    }
</script>

</body>
</html>
