<?php
session_start();
include("connection.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Products - TRY BASKET</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>
    <div class="container">
        <div class="navbar">
            <div class="logo">
                <img src="logo.png" width="125px">
            </div>
            <nav>
                <ul>
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="products.php">PRODUCTS</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="contact.php">CONTACT</a></li>

                    <?php if (isset($_SESSION['Username'])) { ?>
                        <li><a href="#"><img src="images/user-icon.png" width="20px" style="vertical-align: middle;"> <?php echo $_SESSION['Username']; ?></a></li>
                        <li><a href="logout.php">LOGOUT</a></li>
                    <?php } else { ?>
                        <li><a href="account.php">ACCOUNT</a></li>
                    <?php } ?>

                </ul>
            </nav>
            <a href="cart.php"><img src="images/cart.png" width="30px" height="30px"></a>
        </div>
    </div>

    <div class="account-page">
        <div class="container">
            <div class="row">

                <div class="col-2">
                    <img src="images/97.png">
                </div>

                <div class="col-2">
                    <div class="form-container">
                        <div class="form-btn">
                            <span onclick="login()">Login</span>
                            <span onclick="register()">Register</span>
                            <hr id="Indicator">
                        </div>

                        <form id="LoginForm" action="#" method="POST">
                            <input type="text" placeholder="Username" name="Username" required>
                            <input type="password" placeholder="Password" name="Password" required>
                            <button type="Submit" class="btn" name="login">Login</button>
                            <a href="#">Forgot Password?</a>
                            <div class="signup">New Member? <br><a href="#" class="link">Register Here</a></div>
                        </form>

                        <form id="RegForm" action="#" method="POST">
                            <input type="text" placeholder="Username" name="Username" required>
                            <input type="email" placeholder="Email" name="Email" required>
                            <input type="password" placeholder="Password" name="Password" required>
                            <button type="Submit" class="btn" name="Submit">Register</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
// Handle Registration
if (isset($_POST['Submit'])) {
    $Username = $_POST['Username'];
    $Email = $_POST['Email'];
    $Password = $_POST['Password'];

    $sql = "INSERT INTO register (Username, Email, Password) VALUES ('$Username', '$Email', '$Password')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Registration successful! Please login.');</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Handle Login
if (isset($_POST['login'])) {
    $Username = $_POST['Username'];
    $Password = $_POST['Password'];

    $query = "SELECT * FROM register WHERE Username='$Username' && Password='$Password'";
    $data = mysqli_query($conn, $query);
    $total = mysqli_num_rows($data);

    if ($total == 1) {
        $_SESSION['Username'] = $Username;
        header('location:index.php');
    } else {
        echo "<script>alert('Login Failed. Please try again.');</script>";
    }
}
?>

<!-- Footer -->
<div class="footer">
    <div class="container">
        <div class="row">
            <div class="footer-col-1">
                <h3>DOWNLOAD OUR APP</h3>
                <p>Download App for Android and iOS mobile phones.</p>
                <div class="app-logo">
                    <img src="images/play-store.png">
                    <img src="images/app-store.png">
                </div>
            </div>
            <div class="footer-col-2">
                <img src="logo1.jpg">
                <p>Shop With Us and You'll Love The Way You Look</p>
            </div>
            <div class="footer-col-3">
                <h3>USEFUL LINKS</h3>
                <ul>
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="products.php">PRODUCTS</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                    <li><a href="account.php">ACCOUNT</a></li>
                </ul>
            </div>
            <div class="footer-col-4">
                <h3>Follow Us</h3>
                <ul>
                    <li><a href="https://www.facebook.com/" target="_blank">Facebook</a></li>
                    <li><a href="https://www.instagram.com/" target="_blank">Instagram</a></li>
                    <li><a href="https://twitter.com/" target="_blank">Twitter</a></li>
                </ul>
            </div>
        </div>
        <hr>
        <p class="Copyright">TRY BASKET</p>
    </div>
</div>

<script>
    var LoginForm = document.getElementById("LoginForm");
    var RegForm = document.getElementById("RegForm");
    var Indicator = document.getElementById("Indicator");

    function register() {
        RegForm.style.transform = "translateX(0px)";
        LoginForm.style.transform = "translateX(0px)";
        Indicator.style.transform = "translateX(100px)";
    }

    function login() {
        RegForm.style.transform = "translateX(300px)";
        LoginForm.style.transform = "translateX(300px)";
        Indicator.style.transform = "translateX(0px)";
    }
</script>

</body>

</html>