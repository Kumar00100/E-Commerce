<?php 
include("connection.php");

if (isset($_GET['Username'])) {
    $Username= $_GET['Username'];
    $query = "SELECT * FROM register where Username ='$Username'";
    $data = mysqli_query($conn, $query);
    $result=mysqli_fetch_assoc($data);
    $Username = $result['Username'];
    $Email = $result['Email'];
    $Password = $result['Password'];
} 
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="style.css">
        <title>UPDATE REGISTER DATA</title>
    </head>

    <body>
        <div class="title">UPDATE REGISTER DATA</div>

        <form action="#" method="POST">
            <input type="text" placeholder="Username" name="Username" value="<?php echo $Username; ?>">
            <input type="email" placeholder="Email" name="Email" value="<?php echo $Email; ?>">
            <input type="password" placeholder="Password" name="Password" value="<?php echo $Password; ?>">
            <input type="hidden" name="oldUsername" value="<?php echo $Username; ?>">
            <button type="Update" class="btn" name="Update">Update Details</button>
        </form>
    
    </body>
</html> 

<?php
if(isset($_POST['Update'])) {
    $Username = isset($_POST['Username']) ? $_POST['Username'] : '';
    $Email = isset($_POST['Email']) ? $_POST['Email'] : '';
    $Password = isset($_POST['Password']) ? $_POST['Password'] : '';
    $oldUsername = isset($_POST['oldUsername']) ? $_POST['oldUsername'] : '';

    if($Username !== '' && $Email !== '' && $Password !== '') {
        $query ="UPDATE register SET Username='$Username', Email='$Email',Password='$Password' WHERE Username='$oldUsername'";
        $data = mysqli_query($conn,$query);
        
        if($data) {
            echo "<script>alert('Record Updated')</script>";
            ?>
            <meta http-equiv="refresh" content="0; url=http://localhost/PROJECT/E-COMMERCE/accountregisterdata.php" />
            <?php
        } else {
            echo "Failed to Update";
        }
    } else {
        echo "<script>alert('Fill The Form First');</script>";
    }
}
?>
