<?php
session_start(); 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['Add_To_Cart'])) {
        if (isset($_SESSION['cart'])) {
            $myitems = array_column($_SESSION['cart'], 'product_name');
            if(in_array($_POST['product_name'],$myitems))
            {
                echo"<script>
                alert('Item Already Added');
                window.location.href='cart.php';
                </script>";
            }
            else{
            $count = count($_SESSION['cart']);
            $_SESSION['cart'][$count] = array('product_name' => $_POST['product_name'], 'price' => $_POST['price'], 'qty' => 1);
            echo"<script>
                     alert('Item  Added');
                     window.location.href='cart.php';
                 </script>";
            print_r($_SESSION['cart']);
            }
        } else {
            $count = 0; // Initialize $count here
            $_SESSION['cart'][$count] = array('product_name' => $_POST['product_name'], 'price' => $_POST['price'], 'qty' => 1);
            echo"<script>
            alert('Item  Added');
            window.location.href='cart.php';
            </script>";
            print_r($_SESSION['cart']);
        } 
    }   
}
?>
 