<?php
$host = "localhost";          // server name
$user = "root";               // database username
$password = "";               // database password (blank by default in XAMPP)
$dbname = "ecommerce";        // your database name
$port = 3308;                 // <-- very important: correct port

// Connect with port
$conn = mysqli_connect($host, $user, $password, $dbname, $port);

// // Check connection
// if ($conn) {
//     echo "✅ Database connected successfully!";
// } else {
//     die("❌ Database connection failed: " . mysqli_connect_error());
// }
?>
