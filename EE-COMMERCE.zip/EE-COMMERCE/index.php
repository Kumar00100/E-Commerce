<!DOCTYPE html>
<html lang = "en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>All Products - TRY BASKET</title>
        <link rel="stylesheet" href="style.css"> 
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <body>
        <div class="header">
        <div class="container">
                 <div class="navbar">
                         <div class="logo">
                            <img src="logo.png" width="125px">
                         </div>
                     <nav>
                        <ul>
                            <li><a href="index.php">HOME</a></li>
                            <li><a href="products.php">PRODUCTS</a></li>
                            <li><a href="about.php">ABOUT</a></li>
                            <li><a href="contact.php">CONTACT</a></li>
                            <li><a href="account.php">ACCOUNT</a></li>
                        </ul>
                    </nav>
                     <a href="cart.php"><img src="images/cart.png" width="30px" height="30px"></a>
                  </div>
             <div class="row">
                     <div class="col-2">
                         <h1> Super Value Deals<br>On All Products!</h1>
                              <p>Exclusive Deals And Discounts Are Here With Happy Hues Just <br> For You.Trendy And Amazing Fashion Picks Are Now Here On Try Basket.</p>
                         <a href="products.php" class="btn">Explore Now &#8594;</a>
                     </div>
                     <style>
        .col-2 img {
            height: 555px;
        }
    </style>
                 <div class="col-2">
                         <img src="images/555.png">
                </div>
             </div>
      </div>
</div></div>



  <div class="categories">
    <div class="small-container">
        <div class="row">
            <div class="col-3"><a href="orangeshoe.php"><img src="images/category-1.jpg"></div></a>
            <div class="col-3"> <a href="whitesneker.php"><img src="images/category-2.jpg"> </div></a>
            <div class="col-3"> <a href="jacket.php"> <img src="images/category-3.jpg"> </div></a>
        </div>
    </div>
  </div>




  <div class="small-container">
    <h2 class="title">Featured Products</h2>
    <div class="row">
        <div class="col-4">
            <a href="product-details.php">
            <img src="images/product-1.jpg"></a>
            <h4>Red Printed T-Shirt</h4>
            <div class="rating">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-o"></i>
            </div>
            <p>699.00</p>
        </div>
        <div class="col-4">
            <a href="black hrx shoe.php">
            <img src="images/product-2.jpg"></a>
            <h4>Black Casual Shoe</h4>
            <div class="rating">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-half-o"></i>
                <i class="fa fa-star-o"></i>
            </div>
            <p>799.00</p>
        </div>
        <div class="col-4">
            <a href="Men's Jogger.php">
            <img src="images/jog1.png"></a>
            <h4>Men's Jogger</h4>
            <div class="rating">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-half-o"></i>
            </div>
            <p>679.00</p>
        </div>
        <div class="col-4">
            <a href="puma tshirt.php">
            <img src="images/product-4.jpg"></a>
            <h4>Blue Puma Collar T-Shirt</h4>
            <div class="rating">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-o"></i>
            </div>
            <p>1049.00</p>
        </div>
    </div>
    <h2 class="title">Latest Products</h2>
    <div class="row">
        <div class="col-4">
            <a href="pumashoe.php">
            <img src="images/pshoe1.png"></a>
            <h4>Grey Casual Shoe by Puma</h4>
            <div class="rating">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-o"></i>
            </div>
            <p>2099.00</p>
        </div>
        <div class="col-4">
            <a href="pumablack.php">
            <img src="images/pt1.png"></a>
            <h4>Black T-Shirt</h4>
            <div class="rating">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-half-o"></i>
                <i class="fa fa-star-o"></i>
            </div>
            <p>749.00</p>
        </div>
        <div class="col-4">
            <a href="shocks.php">
            <img src="images/product-7.jpg"></a>
            <h4>HRX Shocks(Set of 3)</h4>
            <div class="rating">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-half-o"></i>
            </div>
            <p>599.00</p>
        </div>
        <div class="col-4">
            <a href="fossil.php">
            <img src="images/f1.png"></a>
            <h4>Fossil Black Watch</h4>
            <div class="rating">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-o"></i>
            </div>
            <p>12145.00</p>
        </div>
        <div class="row">
            <div class="col-4">
                <a href="roadsterwatch.php">
                <img src="images/r1.png"></a>
                <h4>Roadster Analog Watch</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>1149.00</p>
            </div>
            <div class="col-4">
                <a href="campusshoe.php">
                <img src="images/c1.png"></a>
                <h4>Campus Sneaker</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>1749.00</p>
            </div>
            <div class="col-4">
                <a href="running.php">
                <img src="images/ru1.png"></a>
                <h4>Running Shoe</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                </div>
                <p>699.00</p>
            </div>
            <div class="col-4">
                <a href="Nike Jogger.php">
                <img src="images/product-12.jpg"></a>
                <h4>Nike Jogger</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>1199.00</p>
            </div>
        </div>
    </div>
  </div>
  <div class="offer">
    <div class="small-container">
        <div class="row">
            <div class="col-2">
               <img src="images/exclusive.png" class="offer-img"> 
            </div>
            <div class="col-2">
            <p>Exclusively Available on TRY BASKET</p>
            <h1>Smart Band 4</h1>
            <small>
                The Mi Smart Band 4 features a 39.9% larger (than Mi Band 3) AMOLED color full-touch 
                display with adjustable brightness,so everything is clear as can be.<br>
            </small>
            <a href="mi band4.php" class="btn">Buy Now &#8594;</a>
            </div>
        </div>
    </div>
  </div>
  <div class="brands">
    <div class="small-container">
        <div class="row">
            <div class="col-5">
                <img src="images/logo-godrej.png">
            </div>
            <div class="col-5">
                <img src="images/logo-oppo.png">
            </div>
            <div class="col-5">
                <img src="images/logo-coca-cola.png">
            </div>
            <div class="col-5">
                <img src="images/logo-paypal.png">
            </div>
            <div class="col-5">
                <img src="images/logo-philips.png">
            </div>
        </div>
    </div>
  </div>

 <div class="footer">
    <div class="container">
        <div class="row">
            <div class="footer-col-1">
                <h3>DOWNLOAD OUR APP</h3>
                <p>Download App for Android and iOS mobile phones.</p>
                <div class="app-logo">
                    <img src="images/play-store.png">
                    <img src="images/app-store.png">
                </div>
            </div>
            <div class="footer-col-2">
                <img src="logo1.jpg">
                <p>Shop With Us and You'll Love The Way You Look</p>
            </div>
            <div class="footer-col-3">
                <h3>USEFUL LINKS</h3>
                <ul>
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="products.php">PRODUCTS</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                    <li><a href="account.php">ACCOUNT</a></li>
                </ul>
            </div>
            <div class="footer-col-4">
                <h3>Follow Us</h3>
                <ul>
                    <li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook-official"></i> Facebook</a></li>
                    <li><a href="https://www.instagram.com/" target="_blank"><i class="fa fa-instagram"></i> Instagram</a></li>
                    <li><a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter"></i> Twitter</a></li>
                </ul>
            </div>
        </div>
        <hr>
        <p class="Copyright"> TRY BASKET</p>
    </div>
</div>
  </body>
  </html>
      