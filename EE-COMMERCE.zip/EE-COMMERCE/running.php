<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>All Products - TRY BASKET</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<body>

    <div class="container">
        <div class="navbar">
            <div class="logo">
               <img src="logo.png" width="125px">
            </div>
            <nav>
                <ul>
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="products.php">PRODUCTS</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                    <li><a href="account.php">ACCOUNT</a></li>
                </ul>
            </nav>
            <a href="cart.php"> <img src="images/cart.png" width="30px" height="30px"></a>
        </div>
    </div>






    <div class="small-container single-product">
        <div class="row">
            <div class="col-2">
                <img src="images/ru1.png" width="100%" id="ProductImg">
                <div class="small-img-row">
                    <div class="small-img-col">
                        <img src="images/ru2.png" width="100%" class="small-img">
                    </div>
                    <div class="small-img-col">
                        <img src="images/ru3.png" width="100%" class="small-img">
                    </div>
                    <div class="small-img-col">
                        <img src="images/ru4.png" width="100%" class="small-img">
                    </div>
                    <div class="small-img-col">
                        <img src="images/ru5.png" width="100%" class="small-img">
                    </div>
                </div> 
            </div>




            <form action="manage_cart.php" method="POST">

            <div class="col-2">
                <p>Home / Shoe</p>
                <h1>Running Shoe</h1>
                <h4>699.00/-</h4>
                <select>
                    <option>Select Size</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                    <option>9</option>
                    <option>10</option>
                </select>
                <input type="number" value="1" min="1" required>
                <button type="submit" name="Add_To_Cart" class="btn">Add To Cart</button>
                <input type="hidden" name="product_name" value="Running Shoe">
                <input type="hidden" name="price" value="699.00">
                <h3>Product Details <i class="fa fa-indent"></i></h3><br>
                <table>
  <tr>
    <td>Color</td>
    <td>Black</td>
  </tr>
  <tr>
    <td>Outer material</td>
    <td>Mesh</td>
  </tr>
  <tr>
    <td>Ideal for</td>
    <td>Men</td>
  </tr>
  <tr>
    <td>Occasion</td>
    <td>Running Shoe</td>
  </tr>
  <tr>
    <td>Sole material</td>
    <td>Synthetic</td>
  </tr>
  <tr>
    <td>Season</td>
    <td>EOSS-4-2023</td>
  </tr>
</table>

            </div>
            </form>
        </div>
    </div>






    <div class="small-container">
        <div class="row row-2">
            <h2> Realated Products </h2>
           
               
           
        </div>
    </div>
    
      <div class="small-container">
                <div class="row">
                    <div class="col-4">
                        <a href="black hrx shoe.php">
                            <img src="images/product-2.jpg" alt="Product Image">
                          </a>
                        <h4>Black Casual Shoe</h4>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star-half-o"></i>
                            <i class="fa fa-star-o"></i>
                        </div>
                        <p>799.00</p>
                    </div>
                    <div class="col-4">
                        <a href="Men's Jogger.php">
                        <img src="images/jog1.png" alt="Product Img"></a>
                        <h4>Men's Jogger</h4>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star-half-o"></i>
                        </div>
                        <p>679.00</p>
                    </div>
                    <div class="col-4">
                        <a href="fossil.php">
                            <img src="images/f1.png"></a>
                            <h4>Fossil Black Watch</h4>
                            <div class="rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-o"></i>
                            </div>
                            <p>12145.00</p>
                        </div>
                        <div class="col-4">
                            <a href="shocks.php">
                            <img src="images/product-7.jpg"></a>
                            <h4>HRX Shocks(Set of 3)</h4>
                            <div class="rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <p>599.00</p>
                        </div>
                </div>
            </div>
        </div>
    
        <div class="footer">
    <div class="container">
        <div class="row">
            <div class="footer-col-1">
                <h3>DOWNLOAD OUR APP</h3>
                <p>Download App for Android and iOS mobile phones.</p>
                <div class="app-logo">
                    <img src="images/play-store.png">
                    <img src="images/app-store.png">
                </div>
            </div>
            <div class="footer-col-2">
                <img src="logo1.jpg">
                <p>Shop With Us and You'll Love The Way You Look</p>
            </div>
            <div class="footer-col-3">
                <h3>USEFUL LINKS</h3>
                <ul>
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="products.php">PRODUCTS</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                    <li><a href="account.php">ACCOUNT</a></li>
                </ul>
            </div>
            <div class="footer-col-4">
                <h3>Follow Us</h3>
                <ul>
                    <li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook-official"></i> Facebook</a></li>
                    <li><a href="https://www.instagram.com/" target="_blank"><i class="fa fa-instagram"></i> Instagram</a></li>
                    <li><a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter"></i> Twitter</a></li>
                </ul>
            </div>
        </div>
        <hr>
        <p class="Copyright"> TRY BASKET</p>
    </div>
</div>
      <script>
        var ProductImg=document.getElementById("ProductImg");
        var SmallImg=document.getElementsByClassName("small-img");
        SmallImg[0].onclick=function()
        {
       ProductImg.src=SmallImg[0].src;
        }
        SmallImg[1].onclick=function()
        {
       ProductImg.src=SmallImg[1].src;
        }
        SmallImg[2].onclick=function()
        {
       ProductImg.src=SmallImg[2].src;
        }
        SmallImg[3].onclick=function()
        {
       ProductImg.src=SmallImg[3].src;
        }
    </script>
  </body>
  </html>
      