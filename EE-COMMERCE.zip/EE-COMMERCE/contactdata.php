<html>
    <head>
        <title>CONTACT DATA</title>
        <style>
            body
                {
                    background:#D071f9;
                }
            table{
                background-color:white;
            }
            .update 
            {
                background-color:green;
                color:white;
                border:0;
                outline:none;
                border-radius:5px;
                height:23px;
                width:80px;
                font-weight:bold;
                cursor:pointer;
            }
            .Delete
            {
                background-color:red;
                color:white;
                border:0;
                outline:none;
                border-radius:5px;
                height:23px;
                width:80px;
                font-weight:bold;
                cursor:pointer;
            }
            </style>
    </head>



<?php include("connection.php");

$query = "SELECT * FROM contact";
$data = mysqli_query($conn, $query);

if(mysqli_num_rows($data) > 0) {
    echo "<h2 align='center'><mark>DISPLAYING CONTACT PAGE DATA</mark></h2>";
    echo "<table border='1' cellspacing='7' width='100%'>";


echo "<tr>
<th width='18%'>Name</th>
<th width='18%'>Email</th>
<th width='22%'>Subject</th>
<th width='30%'>Message </th>
<th width='19%'>Operations </th>

</tr>";





    while($result = mysqli_fetch_assoc($data)) {
        echo "<tr>
                <td>".$result['Name']."</td>
                <td>".$result['Mail']."</td>
                <td>".$result['Subject']."</td>
                <td>".$result['Message']."</td>
            
            
                
                <td>
                <a href='updatecontactdata.php?name=".$result['Name']."&mail=".$result['Mail']."&sub=".$result['Subject']."&msg=".$result['Message']."'>
                    <input type='submit' value='update' class='update'> </a>
               
                <a href='deletecontactdata.php?name=".$result['Name']."&mail=".$result['Mail']."&sub=".$result['Subject']."&msg=".$result['Message']."'>
                    <input type='submit' value='Delete' class='Delete' onclick='return checkdelete()'> </a>
                    
                </td>

                   
             
              </tr>";
    }
    
} else {
    echo "No Record Found";
}
?>
</table>
</center>
<script>
    function checkdelete()
    {
        return confirm('Are you sure to delete this Record ?');
        
    }


</script>