<?php
session_start();
include('connection.php');

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if user exists
    $query = "SELECT * FROM register WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        // User found, login success
        $user = mysqli_fetch_assoc($result);
        
        $_SESSION['user_id'] = $user['id']; 
        $_SESSION['user_name'] = $user['name'];

        echo "<script>alert('Login successful'); window.location.href='index.php';</script>";
    } else {
        // No match found
        echo "<script>alert('Invalid Email or Password'); window.location.href='account.php';</script>";
    }
}
?>
