<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>E COMMERCE WEBSITE</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<body>
 <div class="header">
    <div class="container">
        <div class="navbar">
            <div class="logo">
               <img src="logo.png" width="125px">
            </div>
            <nav>
                <ul>
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="products.php">PRODUCTS</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                    <li><a href="account.php">ACCOUNT</a></li>
                </ul>
            </nav>
            <a href="cart.php"> <img src="images/cart.png" alt="cart" width=30px height=30px></a>
                
            </div>

<section id="contact-details" class="section-p1">
    <div class="details">
        <span>GET IN TOUCH</span>
        <h2>Visit Our Agency Locations or contact us Today</h2>
        <h3>Head Office</h3>
        <div>
            <li>
                <i class="fal fa-map"></i>
                <p>BHUBANESWAR</p>
            </li>
            <li>
                <i class="fal fa-envelope"></i>
                <p>contact@trybasket.com</p>
            </li>
            <li>
                <i class="fal fa-phone-alt"></i>
                <p>+91-9861158519</p>
            </li>
            <li>
                <i class="fal fa-clock"></i>
                <p>Monday To Saturday: 9.00am to 5.00pm</p>
            </li>
        </div>
    </div>

<div class="map">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3740.8202668312847!2d85.80554741484275!3d20.34904238637039!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a1908e025984c55%3A0xee1fcd1f11e55141!2sDLF%20CYBER%20CITY!5e0!3m2!1sen!2sin!4v1681119092827!5m2!1sen!2sin" 
    width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>




</section>
<section id="form-details">
    <form action="#" method="POST">
        <span>LEAVE A MESSAGE</span>
        <h2>We Love To Hear From You</h2>
        <input type="text" name="Name" placeholder="Your Name">
        <input type="text" name="Mail" placeholder="E-Mail">
        <input type="text" name="Subject" placeholder="Subject">
        <textarea name="Message" cols="30" rows="10" placeholder="Your Message"></textarea>
        <button class="btn" name="submit">Submit</button>
    </form>
</section>



<?php
include("connection.php");

$query = "SELECT * FROM contact";
$data = mysqli_query($conn, $query);



if(isset($_POST['submit'])) {
    $Name = isset($_POST['Name']) ? $_POST['Name'] : '';
    $Mail = isset($_POST['Mail']) ? $_POST['Mail'] : '';
    $Subject = isset($_POST['Subject']) ? $_POST['Subject'] : '';
    $Message = isset($_POST['Message']) ? $_POST['Message'] : '';
    
    if($Name !== '' && $Mail !== '' && $Subject !== '' && $Message !== '') {
        $query = "INSERT INTO contact (Name, Mail, Subject, Message) VALUES ('$Name','$Mail','$Subject', '$Message')";
        $result = mysqli_query($conn, $query);
        if($result) {
            echo "Data Inserted Into Database";
        } else {
            echo "Please Fill The Form First";
        }
    }
}
?>


<div class="footer">
    <div class="container">
        <div class="row">
            <div class="footer-col-1">
                <h3>DOWNLOAD OUR APP</h3>
                <p>Download App for Android and iOS mobile phones.</p>
                <div class="app-logo">
                    <img src="images/play-store.png">
                    <img src="images/app-store.png">
                </div>
            </div>
            <div class="footer-col-2">
                <img src="logo1.jpg">
                <p>Shop With Us and You'll Love The Way You Look</p>
            </div>
            <div class="footer-col-3">
                <h3>USEFUL LINKS</h3>
                <ul>
                    <li><a href="index.php">HOME</a></li>
                    <li><a href="products.php">PRODUCTS</a></li>
                    <li><a href="about.php">ABOUT</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                    <li><a href="account.php">ACCOUNT</a></li>
                </ul>
            </div>
            <div class="footer-col-4">
                <h3>Follow Us</h3>
                <ul>
                    <li><a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook-official"></i> Facebook</a></li>
                    <li><a href="https://www.instagram.com/" target="_blank"><i class="fa fa-instagram"></i> Instagram</a></li>
                    <li><a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter"></i> Twitter</a></li>
                </ul>
            </div>
        </div>
        <hr>
        <p class="Copyright"> TRY BASKET</p>
    </div>
</div>
  </body>
  </html>
     
  


